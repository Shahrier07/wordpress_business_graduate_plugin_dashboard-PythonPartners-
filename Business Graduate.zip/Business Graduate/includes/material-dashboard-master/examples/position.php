<!---Custom_textbox creation----->
<?php 

  global $wpdb;
  $table_name = $wpdb->prefix . 'bg_position';
 
  //Political DB
  if (isset($_POST['newsubmit'])) {
    $name = $_POST['newname'];
    $post = $_POST['newpost'];
    $wpdb->query("INSERT INTO $table_name(name,post) VALUES('$name','$post')");
    echo "<script>location.replace('admin.php?page=position');</script>";
  }
  if (isset($_POST['uptsubmit'])) {
    $id = $_POST['uptid'];
    $name = $_POST['uptname'];
    $post = $_POST['uptpost'];
    $wpdb->query("UPDATE $table_name SET name='$name', post='$post' WHERE user_id='$id'");
    echo "<script>location.replace('admin.php?page=position');</script>";
  }
  

  //Economic DB
  if (isset($_POST['newsubmit2'])) {
    $name = $_POST['newname'];
    $post = $_POST['newpost2'];
    $wpdb->query("INSERT INTO $table_name(name,post_2) VALUES('$name','$post')");
    echo "<script>location.replace('admin.php?page=position');</script>";
  }
  if (isset($_POST['uptsubmit2'])) {
    $id = $_POST['uptid'];
    $name = $_POST['uptname'];
    $post = $_POST['uptpost2'];
    $wpdb->query("UPDATE $table_name SET name='$name', post_2='$post' WHERE user_id='$id'");
    echo "<script>location.replace('admin.php?page=position');</script>";
  }

 //Part 3
  if (isset($_POST['newsubmit3'])) {
    $name = $_POST['newname'];
    $post = $_POST['newpost3'];
    $wpdb->query("INSERT INTO $table_name(name,post_3) VALUES('$name','$post')");
    echo "<script>location.replace('admin.php?page=position');</script>";
  }
  if (isset($_POST['uptsubmit3'])) {
    $id = $_POST['uptid'];
    $name = $_POST['uptname'];
    $post = $_POST['uptpost3'];
    $wpdb->query("UPDATE $table_name SET name='$name', post_3='$post' WHERE user_id='$id'");
    echo "<script>location.replace('admin.php?page=position');</script>";
  }

  
 
 ?>

<!-----------Design part-------------->

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
		<link rel="icon" type="image/png" href="../assets/img/favicon.png">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<title>		</title>
		<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
		<!--     Fonts and icons     -->
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
		<!-- CSS Files -->
		 <!-- CSS Files -->
  		<link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  		<!-- CSS Just for demo purpose, don't include it in your project -->
  		<link href="../assets/demo/demo.css" rel="stylesheet" />
		
	</head>
	<body class="" style=" margin: 0; ">
		<div class="wrapper ">
			<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
				<!--
				Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"
				Tip 2: you can also add an image using data-image tag
				-->
				<div class="logo"><a href="#" class="simple-text logo-normal">
				Python Partners
				</a></div>
				<div class="sidebar-wrapper">
					<ul class="nav">
						<li class="nav-item  ">
							<a class="nav-link" href="<?php echo admin_url('admin.php?page=wpplugin') ?>">
								<i class="material-icons">dashboard</i>
								<p>About</p>
							</a>
						</li>
						<li class="nav-item  ">
							<a class="nav-link" href="<?php echo admin_url('admin.php?page=textbox') ?>">
								<i class="material-icons">bubble_chart</i>
								<p>Vision & Mission</p>
							</a>
						</li>
						
						<li class="nav-item ">
							<a class="nav-link" href="<?php echo admin_url('admin.php?page=goals') ?>">
								<i class="material-icons">content_paste</i>
								<p>Goals</p>
							</a>
						</li>
						<li class="nav-item  ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=pest') ?>">
              <i class="material-icons">content_paste</i>
              <p>PEST</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=swot') ?>">
              <i class="material-icons">content_paste</i>
              <p>SWOT</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=strategy') ?>">
              <i class="material-icons">content_paste</i>
              <p>Strategy</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=value_chain') ?>">
              <i class="material-icons">content_paste</i>
              <p>Value Chain</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=bus_model') ?>">
              <i class="material-icons">content_paste</i>
              <p>Business Model</p>
            </a>
          </li>
                <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=ansoff_mat') ?>">
              <i class="material-icons">content_paste</i>
              <p>Ansoff Matrix</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=bcg_mat') ?>">
              <i class="material-icons">content_paste</i>
              <p>BCG Matrix</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=porter_diamond') ?>">
              <i class="material-icons">content_paste</i>
              <p>Porter's Diamond</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=porter_force') ?>">
              <i class="material-icons">content_paste</i>
              <p>Porter's Force</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=cont_plan') ?>">
              <i class="material-icons">content_paste</i>
              <p>Contingency Plan</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=key_res') ?>">
              <i class="material-icons">content_paste</i>
              <p>Key Resources</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=segment') ?>">
              <i class="material-icons">content_paste</i>
              <p>Segmentation</p>
            </a>
          </li>
           <li class="nav-item active">
            <a class="nav-link" href="#">
              <i class="material-icons">content_paste</i>
              <p>Positioning</p>
            </a>
          </li>

					</ul>
				</div>
			</div>
			<div class="main-panel">
				

				<div class="content">
					<div class="container-fluid">
						<div class="container-fluid">
							   
								
									<div class="col-lg-12">
										
<!----------==========================Update Data=====================================---->
			
	   
	     <!---######################----Part 1----#################-->
										    <?php

													          $result = $wpdb->get_results("SELECT * FROM $table_name WHERE post IS NOT NULL");
													         
													          foreach ($result as $print) {
													          	?>
													          	<div class="card">
													            
													            	<tr>
													          					<td><h3><b>Planning to position in your brand:</b></h3></td>
													               </tr>
													              <tr>
													         				
													                <td width='50%'><?php echo $print->post; ?></td>
													                <br><br>

													                <td width='20%'><a href='admin.php?page=position&upt=$print->user_id'><button type='button' style='color: white; background-color: #008CBA;border-radius: 5px;'>EDIT</button></a> </td>
													              </tr>
													            </div>
													         <?php    
													          }
													        ?>

													<!-----Update Part 1------>
													      <?php
													      if (isset($_GET['upt'])) {
													        $upt_id = $_GET['upt'];
													        $result = $wpdb->get_results("SELECT * FROM $table_name WHERE user_id='$upt_id'");
													        foreach($result as $print) {
													          $name = $print->name;
													     
													          $post = $print ->post;
													        }
													      
													     ?>
													        <table class='wp-list-table widefat striped'>

													          <thead>
													            <tr><h3>Update:</h3></tr>
													            <tr>
													              <th width='10%'>Post ID</th>
													              <th width='50%'>Statement</th>
													              <th width='20%'>Actions</th>
													            </tr>
													          </thead>
													          <tbody>

													            <form action='' method='post'>
													              <tr>
													                <td width='20%'><?php echo $print->user_id; ?><input type='hidden' id='uptid' name='uptid' value='<?php echo $print->user_id; ?>'></td>
													               
													              
													                <td width='20%'>
													                 
													                
													                    <!--<input type='text' id='uptpost' name='uptpost' value='<?php echo $print->post ?>'>
													                   --->
													                   <?php  

													                     $content = $print->post;
													                     wp_editor( $content, 'uptpost', array( 'editor_height' => '100px','media_buttons' => false, ) );
													                     wpautop( $content );
													                    ?>
													                </td>
													                <td width='20%'><button id='uptsubmit' name='uptsubmit' type='submit' style='color: white; background-color: green; border-radius: 5px;'>UPDATE</button> <a href='admin.php?page=position'><button type='button'>CANCEL</button></a></td>
													              </tr>
													            </form>
													          </tbody>
													        </table>
													    
													     <?php } ?>


	     <!---######################----part2----#################-->
													 <?php

													          $result = $wpdb->get_results("SELECT * FROM $table_name WHERE post_2 IS NOT NULL");
													          echo "";
													          foreach ($result as $print) {
													          	?>
													             <div class="card">
													            	<tr>
													          					<td><h3><b>Top competitors:</b></h3></td>
													                </tr>
													              <tr>
													          
													                
													                <td width='50%'><?php echo $print->post_2; ?></td>
													                <br><br>
													                <td width='20%'><a href='admin.php?page=position&upt2=$print->user_id'><button type='button' style='color: white; background-color: #008CBA;border-radius: 5px;'>EDIT</button></a></td>
													              </tr>
													            </div>
													        <?php  }
													        ?>   
										<!-----Update part2------>
													       <?php
													      if (isset($_GET['upt2'])) {
													        $upt_id = $_GET['upt2'];
													        $result = $wpdb->get_results("SELECT * FROM $table_name WHERE user_id='$upt_id'");
													        foreach($result as $print) {
													          $name = $print->name;
													     
													          $post = $print ->post_2;
													        }
													      
													     ?>
													        <table class='wp-list-table widefat striped'>

													          <thead>
													            <tr><h3>Update:</h3></tr>
													            <tr>
													              <th width='10%'>Post ID</th>
													             
													              
													              <th width='50%'>Post</th>
													              <th width='20%'>Actions</th>
													            </tr>
													          </thead>
													          <tbody>

													            <form action='' method='post'>
													              <tr>
													                <td width='20%'><?php echo $print->user_id; ?><input type='hidden' id='uptid' name='uptid' value='<?php echo $print->user_id; ?>'></td>
													               
													              
													                <td width='20%'>
													                 
													                
													                    <!--<input type='text' id='uptpost' name='uptpost' value='<?php echo $print->post ?>'>
													                   --->
													                   <?php  

													                     $content = $print->post_2;
													                     wp_editor( $content, 'uptpost2', array( 'editor_height' => '100px','media_buttons' => false, ) );
													                     wpautop( $content );

													                    ?>



													                </td>
													                <td width='20%'><button id='uptsubmit' name='uptsubmit2' type='submit' style='color: white; background-color: green; border-radius: 5px;'>UPDATE</button> <a href='admin.php?page=position'><button type='button'>CANCEL</button></a></td>
													              </tr>
													            </form>
													          </tbody>
													        </table>
													    
													     <?php } ?>

			

			 <!---######################----Part 3----#################-->
													 <?php

													          $result = $wpdb->get_results("SELECT * FROM $table_name WHERE post_3 IS NOT NULL");
													          echo "";
													          foreach ($result as $print) {
													          	?>
													            <div class="card">
													            	<tr>
													          					<td><h3><b>Unique selling propositions:</b></h3></td>
													                </tr>
													              <tr>
													          
													                
													                <td width='50%'><?php echo $print->post_3; ?></td>
													                <br><br>
													                <td width='20%'><a href='admin.php?page=position&upt3=$print->user_id'><button type='button' style='color: white; background-color: #008CBA;border-radius: 5px;'>EDIT</button></a></td>
													              </tr>
													            </div>
													        <?php  }
													        ?>   
										<!-----Update part 3------>
													       <?php
													      if (isset($_GET['upt3'])) {
													        $upt_id = $_GET['upt3'];
													        $result = $wpdb->get_results("SELECT * FROM $table_name WHERE user_id='$upt_id'");
													        foreach($result as $print) {
													          $name = $print->name;
													     
													          $post = $print ->post_3;
													        }
													      
													     ?>
													        <table class='wp-list-table widefat striped'>

													          <thead>
													            <tr><h3>Update:</h3></tr>
													            <tr>
													              <th width='10%'>Post ID</th>
													             
													              
													              <th width='50%'>Post</th>
													              <th width='20%'>Actions</th>
													            </tr>
													          </thead>
													          <tbody>

													            <form action='' method='post'>
													              <tr>
													                <td width='20%'><?php echo $print->user_id; ?><input type='hidden' id='uptid' name='uptid' value='<?php echo $print->user_id; ?>'></td>
													               
													              
													                <td width='20%'>
													                 
													                
													                    <!--<input type='text' id='uptpost' name='uptpost' value='<?php echo $print->post ?>'>
													                   --->
													                   <?php  

													                     $content = $print->post_3;
													                     wp_editor( $content, 'uptpost3', array( 'editor_height' => '100px','media_buttons' => false, ) );
													                     wpautop( $content );

													                    ?>



													                </td>
													                <td width='20%'><button id='uptsubmit' name='uptsubmit3' type='submit' style='color: white; background-color: green; border-radius: 5px;'>UPDATE</button> <a href='admin.php?page=position'><button type='button'>CANCEL</button></a></td>
													              </tr>
													            </form>
													          </tbody>
													        </table>
													    
													   <?php } ?>	


	
       
















<!----------==========================Insert Data=====================================---->
						
						<div class="container">
								<div class="row">

							<!-------##---- Part 1----##----->						        
								
										<div class="col-lg-12">
											<p id="success"></p>
											<div class="table-wrapper">
												<div class="table-title">						
												
												</div>
												
                  			<div class="table-responsive col-sm-12">    
													<table class="table table-striped table-hover">
														
														<thead>
													        
													     </thead>
														<tbody>
															<?php  
                              $result = $wpdb->get_var("SELECT count(*) FROM $table_name WHERE post IS NOT NULL"); 
                              if ($result==0) {
                              ?>  
															<form action="" method="post">
													          <tr><div class="col-sm-12">
																					<h3><b>How are you planning to position in your brand?</b></h3>
																				</div>
																		</tr>
													          <tr>
													           						           
													            <td>
													              <!----<input type="text" id="newpost" name="newpost">--->
													               <?php  wp_editor( $epn_doi_body, 'newpost', array( 'editor_height' => '100px','media_buttons' => false, ) );
													             wpautop( $epn_doi_body );

													             ?>

													            </td>
													          </tr>
													          <tr> <td><button id="newsubmit" name="newsubmit" type="submit" style="color: white; background-color: #008CBA;border-radius: 5px;">Save</button></td></tr>
													        </form>
													      <?php } ?>
													        
													      </tbody>  
													    </table>
														  </div>
														 
												
											    </div>
												  </div>								
			
							<!---#####------Part 2 -#######-->
										
										<div class="col-lg-12">
					 					  <p id="success"></p>
											<div class="table-wrapper">
												<div class="table-title">
													<div class="row">
														
														
													</div>
												</div>
												
                  								<div class="table-responsive col-sm-12">    
													<table class="table table-striped table-hover">
														
														<thead>
													        
													  </thead>
														<tbody>
															<?php  
                              $result = $wpdb->get_var("SELECT count(*) FROM $table_name WHERE post_2 IS NOT NULL"); 
                              if ($result==0) {
                              ?>  
															<form action="" method="post">
													         <tr><div class="col-sm-12">
																			<h3><b>Who are your top competitors?</b></h3>
																			</div>
																		</tr>
													          <tr>
													           
													            <td>
													              <!----<input type="text" id="newpost" name="newpost">--->
													               <?php  wp_editor( $epn_doi_body, 'newpost2', array( 'editor_height' => '100px','media_buttons' => false, ) );
													             wpautop( $epn_doi_body );

													             ?>

													            </td>
													          </tr>
													          <tr> <td><button id="newsubmit2" name="newsubmit2" type="submit" style="color: white; background-color: #008CBA;border-radius: 5px;">Save</button></td></tr>
													        </form>
													      <?php } ?>
													       
													      </tbody>  
													    </table>
														  </div>		 
											    </div>
												  </div>

							<!-------##---- Part 3----##----->						        
										<div class="col-lg-12">
											<p id="success"></p>
											<div class="table-wrapper">
												<div class="table-title">
													
												</div>
												
                  			<div class="table-responsive col-sm-12">    
													<table class="table table-striped table-hover">
														
														<thead>
													        
													     </thead>
														<tbody>
															<?php  
                              $result = $wpdb->get_var("SELECT count(*) FROM $table_name WHERE post_3 IS NOT NULL"); 
                              if ($result==0) {
                              ?>  
															<form action="" method="post">
													          
																		<tr><div class="col-sm-12">
																			<h3><b>Who are your unique selling propositions?</b></h3>
																				</div>
																		</tr>	
													          <tr>
													           						           
													            <td>
													              <!----<input type="text" id="newpost" name="newpost">--->
													               <?php  wp_editor( $epn_doi_body, 'newpost3', array( 'editor_height' => '100px','media_buttons' => false, ) );
													             wpautop( $epn_doi_body );

													             ?>

													            </td>
													          </tr>
													          <tr> <td><button id="newsubmit3" name="newsubmit3" type="submit" style="color: white; background-color: #008CBA;border-radius: 5px;">Save</button></td></tr>
													        </form>
													       <?php } ?>
													        
													      </tbody>  
													    </table>
													   
														  </div>
											    </div>
												  </div>
													</div>
											
										
						
							
							</div>
						</div>
					</div>
				</div>
		
		<!--   Core JS Files   -->
		
		
		









	</body>
</html>