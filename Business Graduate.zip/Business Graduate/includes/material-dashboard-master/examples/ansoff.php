<!---Custom_textbox creation----->
<?php 

  global $wpdb;
  $table_name = $wpdb->prefix . 'bg_ansoff';
 
  //Vision DB
  if (isset($_POST['newsubmit'])) {
    $name = $_POST['newname'];
    $post = $_POST['newpost'];
    $post_2 = $_POST['newpost2'];
    $wpdb->query("INSERT INTO $table_name(name,post, post_2) VALUES('$name','$post','$post_2' )");
    echo "<script>location.replace('admin.php?page=ansoff_mat');</script>";
  }
  if (isset($_POST['uptsubmit'])) {
    $id = $_POST['uptid'];
    $name = $_POST['uptname'];
    $post = $_POST['uptpost'];
    $post_2 = $_POST['uptpost2'];
    $wpdb->query("UPDATE $table_name SET name='$name', post='$post', post_2='$post_2' WHERE user_id='$id'");
    echo "<script>location.replace('admin.php?page=ansoff_mat');</script>";
  }
 
  

 ?>


<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8" />
		<link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
		<link rel="icon" type="image/png" href="../assets/img/favicon.png">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<title>		</title>
		<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
		<!--     Fonts and icons     -->
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
		<!-- CSS Files -->
		 <!-- CSS Files -->
  		<link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  		<!-- CSS Just for demo purpose, don't include it in your project -->
  		<link href="../assets/demo/demo.css" rel="stylesheet" />
		
	</head>
	<body class="">
		<div class="wrapper ">
			<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
				<!--
				Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"
				Tip 2: you can also add an image using data-image tag
				-->
				<div class="logo"><a href="#" class="simple-text logo-normal">
				Python Partners
				</a></div>
				<div class="sidebar-wrapper">
					<ul class="nav">
						<li class="nav-item  ">
							<a class="nav-link" href="<?php echo admin_url('admin.php?page=wpplugin') ?>">
								<i class="material-icons">dashboard</i>
								<p>About</p>
							</a>
						</li>
						<li class="nav-item  ">
							<a class="nav-link" href="<?php echo admin_url('admin.php?page=textbox') ?>">
								<i class="material-icons">bubble_chart</i>
								<p>Vision & Mission</p>
							</a>
						</li>
						
						<li class="nav-item ">
							<a class="nav-link" href="<?php echo admin_url('admin.php?page=goals') ?>">
								<i class="material-icons">content_paste</i>
								<p>Goals</p>
							</a>
						</li>
						<li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=pest') ?>">
              <i class="material-icons">content_paste</i>
              <p>PEST</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=swot') ?>">
              <i class="material-icons">content_paste</i>
              <p>SWOT</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=strategy') ?>">
              <i class="material-icons">content_paste</i>
              <p>Strategy</p>
            </a>
          </li>
          </li>
            <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=value_chain') ?>">
              <i class="material-icons">content_paste</i>
              <p>Value Chain</p>
            </a>
          </li>
            <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=bus_model') ?>">
              <i class="material-icons">content_paste</i>
              <p>Business Model</p>
            </a>
          </li>
            <li class="nav-item active ">
            <a class="nav-link" href="#">
              <i class="material-icons">content_paste</i>
              <p>Ansoff Matrix</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=bcg_mat') ?>">
              <i class="material-icons">content_paste</i>
              <p>BCG Matrix</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=porter_diamond') ?>">
              <i class="material-icons">content_paste</i>
              <p>Porter's Diamond</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=porter_force') ?>">
              <i class="material-icons">content_paste</i>
              <p>Porter's Force</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=cont_plan') ?>">
              <i class="material-icons">content_paste</i>
              <p>Contingency Plan</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=key_res') ?>">
              <i class="material-icons">content_paste</i>
              <p>Key Resources</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=segment') ?>">
              <i class="material-icons">content_paste</i>
              <p>Segmentation</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#">
              <i class="material-icons">content_paste</i>
              <p>Positioning</p>
            </a>
          </li>

					</ul>
				</div>
			</div>
			<div class="main-panel">
			
				<div class="content">
					<div class="container-fluid">
						<div class="container-fluid">
							   
								<div class="">
									<div class="col-lg-12">
												
	
	    
									


	<!---######################----pART 1----#################-->
													 <?php

													          $result = $wpdb->get_results("SELECT * FROM $table_name WHERE post_2 IS NOT NULL");
													          echo "";
													          foreach ($result as $print) {
													          	?>
													          <div class="card">
													            	<tr>
													          					<td><h3><b>Growth Strategy</b>(Based on Ansoff Matrix)</h3></td>
													              </tr>
													              <tr>
													              	<td width='50%'><?php echo $print->post; ?></td>
													              </tr>

													            	<tr>
													          					<td><h3><b>Growth strategy</b></h3></td>
													              </tr>
													              <tr>
													                <td width='50%'><?php echo $print->post_2; ?></td>
													              </tr>
													              <tr><br><br></tr>
													              <tr>  
													                <td width='20%'><a href='admin.php?page=ansoff_mat&upt=$print->user_id'><button type='button' style='color: white; background-color: #008CBA;border-radius: 5px;'>EDIT</button></a></td>
													              </tr>
													            </div>
													        <?php  }
													        ?>   
										<!-----Update part2------>
													       <?php
													      if (isset($_GET['upt'])) {
													        $upt_id = $_GET['upt'];
													        $result = $wpdb->get_results("SELECT * FROM $table_name WHERE user_id='$upt_id'");
													        foreach($result as $print) {
													          $name = $print->name;
													     
													          $post = $print ->post_2;
													        }
													      
													     ?>  
													        <br><br><br>
													        <table class='wp-list-table widefat striped'>


													         <form action="" method="post">
														         <tr>
															       </tr>	
														          <tr>
														            <td>

																					<h3>Update your strategy:</h3>
															     		
                                          <select name="uptpost" class="form-select form-select-lg mb-3" aria-label="Default select example">
																						<option value="Market Penetration">Market Penetration</option>
																						<option value="Market Development">Market Development</option>
																						<option value="Product Development">Product Development</option>
																						<option value="Diversification">Diversification</option>
																					
																					</select>
														             </td>
														            </tr>
														            <tr></tr>
														            <tr>
														            	 <td><h3>Update Growth strategy </h3></td>
														            </tr>
														            <tr>
                                          <td width='20%'><?php echo $print->user_id; ?><input type='hidden' id='uptid' name='uptid' value='<?php echo $print->user_id; ?>'></td>
                                         
                                        
                                          <td width='30%'>
                                           
                                          
                                
                                             <?php  

                                               $content = $print->post_2;
                                               wp_editor( $content, 'uptpost2', array( 'editor_height' => '100px','media_buttons' => false, ) );
                                               wpautop( $content );

                                              ?>

                                          </td>
                                          <td width='10%'><button id='uptsubmit' name='uptsubmit' type='submit' style='color: white; background-color: green; border-radius: 5px;'>UPDATE</button> <a href='admin.php?page=ansoff_mat'><button type='button'>CANCEL</button></a></td>
                                        </tr>
														         
														          
														        </form>
													        </table>";
													    
													     <?php } ?>


							<!-------##---- Part 1----##----->						        
										<div class="container">
											<p id="success"></p>
											<div class="table-wrapper">
												<div class="table-title">
													<div class="row">
														
														
													</div>
												</div>
												
                  			<div class="table-responsive col-sm-12">    
													<table class="table table-striped table-hover">
														
														<thead>
													        
													     </thead>
														<tbody>
															<?php  
															$result = $wpdb->get_var("SELECT count(*) FROM $table_name WHERE post IS NOT NULL"); 
															if ($result==0) {
															?>	
													
																<form action="" method="post">
														         <tr>
																					<h3>Based on Ansoff Matrix, what is your growth strategy?</h3>
															     			
															       </tr>	
														          <tr>
														            <td>
                                          <select name="newpost" class="form-select form-select-lg mb-3" aria-label="Default select example">
																						<option value="Market Penetration">Market Penetration</option>
																						<option value="Market Development">Market Development</option>
																						<option value="Product Development">Product Development</option>
																						<option value="Diversification">Diversification</option>
																					
																					</select>
														             </td>
														            </tr>
														            <tr><br><br></tr>
														            <tr>
														            	 <td><h3>Explain your growth strategy</h3>
													              <!----<input type="text" id="newpost" name="newpost">--->
													               <?php  wp_editor( $epn_doi_body, 'newpost2', array( 'editor_height' => '100px','media_buttons' => false, ) );
													            	 wpautop( $epn_doi_body );

													             ?>

													               </td>
														            </tr>
														         
														          <tr> <td><button id="newsubmit" name="newsubmit" type="submit" style="color: white; background-color: #008CBA;border-radius: 5px;">Save</button></td></tr>
														        </form>
														    <?php } ?>
													        
													      </tbody>  
													    </table>
													 
													   
														  </div>
														 
											
											    </div>
												  </div>
												
										

									
									
						

									
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--   Core JS Files   -->
		
		
		















	</body>
</html>