<!--
=========================================================
Material Dashboard - v2.1.2
=========================================================
 -->




<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Business Graduate Plugin by Python Partners
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="#" class="simple-text logo-normal">
         Python Partners
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="">
              <i class="material-icons">dashboard</i>
              <p>About</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=textbox') ?>">
              <i class="material-icons">bubble_chart</i>
              <p>Vision & Mission </p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=goals') ?>">
              <i class="material-icons">content_paste</i>
              <p>Goals</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=pest') ?>">
              <i class="material-icons">content_paste</i>
              <p>PEST</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=swot') ?>">
              <i class="material-icons">content_paste</i>
              <p>SWOT</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=strategy') ?>">
              <i class="material-icons">content_paste</i>
              <p>Strategy</p>
            </a>
          </li>
            <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=value_chain') ?>">
              <i class="material-icons">content_paste</i>
              <p>Value Chain</p>
            </a>
          </li>
            <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=bus_model') ?>">
              <i class="material-icons">content_paste</i>
              <p>Business Model</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=ansoff_mat') ?>">
              <i class="material-icons">content_paste</i>
              <p>Ansoff Matrix</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=bcg_mat') ?>">
              <i class="material-icons">content_paste</i>
              <p>BCG Matrix</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=porter_diamond') ?>">
              <i class="material-icons">content_paste</i>
              <p>Porter's Diamond</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=porter_diamond') ?>">
              <i class="material-icons">content_paste</i>
              <p>Porter's Five Forces</p>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=cont_plan') ?>">
              <i class="material-icons">content_paste</i>
              <p>Contingency Plan</p>
            </a>
          </li>
           <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=key_res') ?>">
              <i class="material-icons">content_paste</i>
              <p>Key Resources</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=segment') ?>">
              <i class="material-icons">content_paste</i>
              <p>Segmentation</p>
            </a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#">
              <i class="material-icons">content_paste</i>
              <p>Positioning</p>
            </a>
          </li>

      
          
         
         
        </ul>
      </div>
    </div>
    <div class="main-panel">
    
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
                

         <div class="home_text " >
              <marquee  width="100%" direction="left"  height="100%" >
                         <h1>Business Graduate Plugin by <b>Python Partners</b></h1>
              </marquee>     
         </div>  

          
        <div class="row">

          <!---------1st----------->
          <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Vision and Mision</h4>
                </div>
                 <div class="card-body" >
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  A statement that encapsulates
                    the overriding purpose and objectives of an organization. It is used to
                    communicate this purpose to all stakeholder groups, both internal and
                    external, and to guide employees in their contribution towards achieving it.
                  </p>
                 </div>
              </div>
            </div>
            

            <!-------3rd--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">PEST</h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">    Analysis of the external influences on a firm: the
                      acronym stands for political, economic, social and technological i.e. issues that could significantly affect the strategic
                      development of a firm. The former acronym, PEST, has been expanded to
                      include the legal and environmental aspects.

                  </p>
                 </div>
              </div>
            </div>
            <!-------2nd--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Goals</h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">The practice of setting individual performance targets for
                    employees. To maximize performance and increase *motivation four
                    general principles should be followed: (1) goals should be challenging but
                    realistic; (2) goals should be specific, not vague; (3) employees should have
                    involvement in setting these goals; and (4) goals should be measurable.
                  </p>
                 </div>
              </div>
            </div>
             <!-------4th--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">SWOT</h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  Acronym for strengths, weaknesses, opportunities, and threats.
                    When planning to market of a new product a company needs to embark on
                    a SWOT analysis to assess its strengths and weaknesses (internally) and the
                    opportunities and threats facing it (externally). Internal strengths could be a
                    good distribution system and adequate cash flow. Weaknesses might be
                    identified as an already extended product line or poor servicing facilities.
                    Opportunities could be consumer demand for a particular product or the
                    vulnerability of a competitor, while threats might be forthcoming
                    government legislation or diversification by a competitor.

                  </p>
                 </div>
              </div>
            </div>
            
            <!-------6th--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Business Continuity Management <b>(BCM)</b></h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  A <b>risk management</b>
                    process designed to ensure the continuity of a business’s key activities in
                    the case of a major disruptive event (e.g. an IT systems breakdown or an
                    epidemic of illness among staff). It involves identifying the key activities of
                    a company, the resources needed to deliver them (e.g. personnel, systems,
                    plant and machinery), and the major risks affecting these resources; a
                    strategy must then be developed to restore key activities as soon as possible
                    after any disruption. Once in place, a business continuity plan should be
                    reviewed frequently in the light of any changes. *Scenario analysis can be
                    used to test a BCM plan but should not be used to drive its formulation,
                    because of the near-infinite number of possible scenarios. 

                  </p>
                 </div>
              </div>
            </div>
            <!-------7th--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Market Segmentation </h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  The division of a *market into homogeneous
                    groups of consumers, each of which can be expected to respond to a
                    different *marketing mix. There are numerous ways of segmenting markets,
                    the more traditional being by age, sex, family size, income, occupation, and
                    social class; more recently *geodemographic segmentation, which identifies
                    housing areas in which people share a common lifestyle and will be more
                    likely to buy certain types of products, has become more popular. Another
                    frequently used method is *benefit segmentation. Once a segment has been
                    identified, the marketer can then develop a unique marketing mix to reach
                    it, for example by advertising only in the newspapers read by that market
                    segment. Therefore, to be of practical value a market segment must be large
                    enough to warrant the development costs.

                   

                  </p>
                 </div>
              </div>
            </div>
             <!-------8th--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Positioning</h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  A marketing strategy that will position a company’s products
                    and services against those of its competitors in the minds of consumers. To
                    achieve positioning success it is suggested that there are four basic
                    competitive strategies that a company can follow. The three winning
                    strategies are:
                    <ul>
                    <li><b>cost leadership</b>—the company tries to achieve lowest costs of production and distribution;</li>
                    <li><b>differentiation</b>—making use of specific marketing mixes.</li>
                    <li><b>focus</b>—paying attention to a few market segments.</li>
                    </ul>
                   

                  </p>
                 </div>
              </div>
            </div>
            <!-------5th--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Business Strategy</h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  An overall longer-term policy for a firm that
                    coordinates the separate functional areas of a business. It defines the
                    business objectives, analyses the internal and external environments, and
                    determines the direction of the firm. Each firm operates in a competitive
                    environment and seeks to formulate a strategy that will provide it with an
                    advantage over its rivals: design, quality, innovation, and branding are
                    examples of ways in which <b>competitive advantage</b> may be established.

                  </p>
                 </div>
              </div>
            </div>
            <!-------9th--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Value Chain </h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  The chain of activities by which a good or service is
                    produced, distributed, and marketed. Each step of the chain (which may consist of the activities of one company or of several) creates different amounts of value for the consumer. There are five value-creating activities:

                    <ul>
                        • inbound distribution
                        • operations
                        • outbound distribution
                        • marketing
                        • after-sales service;
                        and four supporting activities:
                        • buying
                        • research and development
                        • human resource management
                        • infrastructure of the firm.

                    </ul>

                    For management, the main application of the value-chain concept is that a
                    company should examine its costs and performance at each stage, and
                    decide, among other things, whether it is best to carry out a particular stage
                    in house or externally.

                   

                  </p>
                 </div>
              </div>
            </div>
            
            <!-------11th--------->
            <div class="col-6">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Porter’s Five Forces </h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  
                    A framework for analysing the balance of power
                    within a particular industry and hence its overall profitability. The frame
                    identifies five forces in the *microenvironment that drive competition and
                    threaten a firm’s ability to make profits: (1) rivalry between existing
                    competitors (depending on e.g. their number, size, and relative market
                    shares); (2) the threat of new entrants (i.e. the extent to which there are
                    significant *barriers to entry); (3) the threat of substitutes (i.e. products in
                    another industry that the consumer may see as alternatives); (4) the strength
                    of buyer power; and (5) the strength of supplier power. Forces (2), (3), (4),
                    and (5) all feed back into force (1) by driving up competitive rivalry. The
                    five-forces model is probably the most widely used tool in *industry
                    structure analysis and is also a popular starting point in *strategic
                    management. It was developed by Michael E. Porter of Harvard Business
                    School in the late 1970s. 

                    
                   

                   

                  </p>
                 </div>
              </div>
            </div>
             <!-------10th--------->
            <div class="col-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Boston Matrix <b>(BCG Matrix)</b>  </h4>
                </div>
                 <div class="card-body ">
                  <p style="text-align: justify; font-size: 16px;line-height: 1.6;">  A means of analysing and categorizing
                    the performance of business units in large diversified firms by reference to
                    market share and growth rates. Four main categories
                    are displayed in a two-dimensional matrix, which seeks to identify those
                    business units that generate cash and those that use it, and then to relate the
                    position of the business units to the formulation of an overall business
                    strategy. 


                    <ul>
                        <li>• <b>Cash Cows:</b> mature businesses or products with a high market share but
                        low growth rate. Typically, most fixed investment has already been made
                        and a substantial cash flow is generated, the surplus being used to develop
                        and support other businesses or products requiring higher levels of
                        investment and marketing support.</li>

                        <li>• <b>Stars:</b> businesses or products with a high rate of growth, which are often
                        able to generate sufficient cash to fund the high investment necessary to
                        meet increasing demand. As the market matures, such businesses or
                        products should be managed in order to become future cash cows.</li>
                        <li>• <b>Question Marks (or Problem Children): </b>although operating in a
                        growth market, the low market share is likely to mean that these business
                        units are unable to sustain the required level of investment needed in order
                        to try and turn them into stars. Competitor pressures may result in such a
                        business or product becoming a dog.</li>
                        <li>• <b>Dogs:</b> the combination of low growth rate and market share is typical of
                        these businesses and products, which operate in mature markets. Firms
                        frequently face strategic decisions whether to continue to support dogs or
                        to implement a divestment strategy. *Barriers to exit would also need to
                        be considered. </li>

                    </ul>

                  </p>
                 </div>
              </div>
            </div>
            
            
            
            












         </div> <!----------row ends-------->
            
         </div>
        </div>
      </div>
      
    </div>

 
  
 
  
</body>

</html>