<?php

function dashboard_pages()
{
  add_menu_page(
    __( 'Business Graduate Plugin', 'wpplugin' ),
    __( 'Business Graduate Plugin', 'wpplugin' ),
    'manage_options',
    'wpplugin', //slug
    'settings_page_markup',
    'dashicons-wordpress-alt',
    2
  );
  add_submenu_page(
    'wpplugin',
    __( 'Text Box', 'wpplugin' ),
    __( 'Vision & Mission', 'wpplugin' ),
    'manage_options',
    'textbox',
    'textbox_markup'
  );

  add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 2', 'wpplugin' ),
    __( 'Goals', 'wpplugin' ),
    'manage_options',
    'goals',
    'goal_markup'
  );
  add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 3', 'wpplugin' ),
    __( 'PEST', 'wpplugin' ),
    'manage_options',
    'pest',
    'pest_markup'
  );
  add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 4', 'wpplugin' ),
    __( 'SWOT', 'wpplugin' ),
    'manage_options',
    'swot',
    'swot_markup'
  );
   add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 5', 'wpplugin' ),
    __( 'Strategy', 'wpplugin' ),
    'manage_options',
    'strategy',
    'strategy_markup'
  );
    add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 6', 'wpplugin' ),
    __( 'Value Chain', 'wpplugin' ),
    'manage_options',
    'value_chain',
    'value_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 7', 'wpplugin' ),
    __( 'Business Model', 'wpplugin' ),
    'manage_options',
    'bus_model',
    'business_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 8', 'wpplugin' ),
    __( 'Ansoff Matrix', 'wpplugin' ),
    'manage_options',
    'ansoff_mat',
    'ansoff_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 9', 'wpplugin' ),
    __( 'BCG Matrix', 'wpplugin' ),
    'manage_options',
    'bcg_mat',
    'bcg_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 10', 'wpplugin' ),
    __( "Porter's Diamond", 'wpplugin' ),
    'manage_options',
    'porter_diamond',
    'porter_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 11', 'wpplugin' ),
    __( "Porter's Five Forces", 'wpplugin' ),
    'manage_options',
    'porter_force',
    'porter_force_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 12', 'wpplugin' ),
    __( "Contingency Plan", 'wpplugin' ),
    'manage_options',
    'cont_plan',
    'contingency_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 13', 'wpplugin' ),
    __( "Key Resources", 'wpplugin' ),
    'manage_options',
    'key_res',
    'key_markup'
  );
      add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 14', 'wpplugin' ),
    __( "Segmentation", 'wpplugin' ),
    'manage_options',
    'segment',
    'segment_markup'
  );
     add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 15', 'wpplugin' ),
    __( "Positioning", 'wpplugin' ),
    'manage_options',
    'position',
    'position_markup'
  );
     

}
add_action( 'admin_menu', 'dashboard_pages' );

// Add a link to your settings page in your plugin
function wpplugin_add_settings_link( $links ) {
    $settings_link = '<a href="admin.php?page=wpplugin">' . __( 'Settings' ) . '</a>';
    array_push( $links, $settings_link );
    return $links;
}
$filter_name = "plugin_action_links_" . plugin_basename( __FILE__ );


///==================

add_filter( $filter_name, 'wpplugin_add_settings_link' );


function settings_page_markup()
{
  // Double check user capabilities
  if ( !current_user_can('manage_options') ) {
      return;
  }else{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/dashboard.php'); 
    //include( plugin_dir_path( __FILE__ ) . 'custom_dashboard/index.html'); 
  }
}
function textbox_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/vision&mission.php');
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_vision_mission';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function goal_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/goals.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_goals';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}

function pest_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/pest.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_pest';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function swot_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/swot.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_swot';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function strategy_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/strategy.php');
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_strategy';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}

function value_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/value.php');
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_value';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,
    `post_5` varchar(220) DEFAULT NULL,
    `post_6` varchar(220) DEFAULT NULL,
    `post_7` varchar(220) DEFAULT NULL,
    `post_8` varchar(220) DEFAULT NULL,
    `post_9` varchar(220) DEFAULT NULL,
    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function business_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/business.php');
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_business';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,
    `post_5` varchar(220) DEFAULT NULL,
    `post_6` varchar(220) DEFAULT NULL,
    `post_7` varchar(220) DEFAULT NULL,
    `post_8` varchar(220) DEFAULT NULL,
    `post_9` varchar(220) DEFAULT NULL,
    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function ansoff_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/ansoff.php');
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_ansoff';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function bcg_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/bcg.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_bcg';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,
    `post_5` varchar(220) DEFAULT NULL,

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function porter_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/porter.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_porter';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,

  

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function porter_force_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/porter_force.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_porter_force';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,
    `post_5` varchar(220) DEFAULT NULL,
    
  

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}

function contingency_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/cont_plan.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_cont_plan';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,
    `post_5` varchar(220) DEFAULT NULL,
    `post_6` varchar(220) DEFAULT NULL,
  

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function key_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/key_res.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_key_res';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,
    `post_5` varchar(220) DEFAULT NULL,
    `post_6` varchar(220) DEFAULT NULL,
  

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function segment_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/segment.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_segment';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
    `post_4` varchar(220) DEFAULT NULL,
    
  

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function position_markup()
{
  include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/position.php');
   global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bg_position';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `name` varchar(220) DEFAULT NULL,
    `post` varchar(220) DEFAULT NULL,
    `post_2` varchar(220) DEFAULT NULL,
    `post_3` varchar(220) DEFAULT NULL,
   
    
    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}

///=================================///

?>